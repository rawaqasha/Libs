#!/bin/bash

set -e

wine /work/megacc.exe
