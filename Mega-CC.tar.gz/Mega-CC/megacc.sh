#!/bin/bash

set -e

wine /Mega-CC/megacc.exe
